<?php
$meta = $this->menu_m->select_meta()->row();
?>
<div class="page-footer">
	<div class="page-footer-inner">
		<?=date('Y'); ?> &copy; <?=$meta->meta_name;?> | Repost by <a href='https://stokcoding.com/' title='StokCoding.com' target='_blank'>StokCoding.com</a>
		
	</div>
	<div class="scroll-to-top">
	    <i class="icon-arrow-up"></i>
	</div>
</div>